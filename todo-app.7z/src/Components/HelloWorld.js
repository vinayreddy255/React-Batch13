const HelloWorld = (props) => {
  return (
    <div>
      <h1>Hello React js world....Project...</h1>
      {/* {props.children} */}
    </div>
  );
};

/* function HelloWorld (props) {
  return (
    <div>
      <h1>Hello React js world....Project...</h1>
    </div>
  );
}; */

export default HelloWorld;
